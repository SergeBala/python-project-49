### Hexlet tests and linter status:
[![Actions Status](https://github.com/SergeBala/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/SergeBala/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/ca64fcd7cca8fe913c0b/maintainability)](https://codeclimate.com/github/SergeBala/python-project-49/maintainability)